#include <stdio.h>  
#include <stdlib.h>  
#include <memory.h>  
#include <pthread.h>  
#include <errno.h>  
#include <math.h>  
#include <semaphore.h>

sem_t rmutex;
sem_t wmutex;
int wnum=0;
int rnum=0;
int buf[3]={0};

void read()
{ 
  rnum++;
  printf("reader numer %d\n", (rnum%3)+1);
  sleep(2);
}

void write()
{   
    wnum++;
    printf("write number %d\n",(wnum%3)+1);
    sleep(2);
}

void *reader(void *arg)
{
    while(1)
    {
        sem_wait(&rmutex);
        if(rnum==0)
        {
            sem_wait(&wmutex);
        }
        rnum++;
        sem_post(&rmutex);

        read();

        sem_wait(&rmutex);
        rnum--;
        if(rnum==0)
        {
            sem_post(&wmutex);
        }
        sem_post(&rmutex);
    }
    pthread_exit(NULL);
}

void *writer(void *arg)
{
    while(1)
    {
        sem_wait(&wmutex);
        write();
        sem_post(&wmutex);
    }
    pthread_exit(NULL);
}

int main()
{
    sem_init(&rmutex,0,1);
    sem_init(&wmutex,0,1);

    pthread_t tid;
    int ret=0,i;
    for(i=0;i<3;i++)
    {
        pthread_create(&tid,NULL,writer,NULL);
        if(ret<0)
        {
            perror("pthread_create");
            exit(0);
        }
    }
    for(i=0;i<5;i++)
    {
        pthread_create(&tid,NULL,reader,NULL);
        if(ret<0)
        {
            perror("pthread_create");
            exit(0);
        }
    }

    pthread_join(tid,NULL);

    return 0;
}
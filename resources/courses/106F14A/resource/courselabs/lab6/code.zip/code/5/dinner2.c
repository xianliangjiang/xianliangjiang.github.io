#include <stdio.h>  
#include <stdlib.h>  
#include <memory.h>  
#include <pthread.h>  
#include <errno.h>  
#include <math.h>  
#include <semaphore.h>

sem_t room;
sem_t chip[5];

void *philosopher(void *arg)
{
    int i=0;
    i=*((int *)arg);
    while(1)
    {
        printf("philosoper %d thinking\n",i);
        sem_wait(&room);
        sem_wait(&chip[i]);
        sem_wait(&chip[(i+1)%5]);
        printf("philosopher %d eating\n",i);
        sem_post(&chip[(i+1)%5]);
        sem_post(&chip[i]);
        sem_post(&room);
        sleep(2);
    }
    pthread_exit(NULL);
}

int main()
{
    sem_init(&room,0,4);
    int i=0;
    int arg[5]={0};
    for(i=0;i<5;i++)
    {
        sem_init(chip+i,0,1);
        arg[i]=i;
    }

    int ret=0;
    pthread_t tid;
    for(i=0;i<5;i++)
    {
        ret=pthread_create(&tid,NULL,philosopher,(void *)&arg[i]);
        if(ret<0)
        {
            perror("pthread_create");
            exit(0);
        }
    }

#if 0
    while(1)
    {
        sleep(2);
    }   
#endif

    pthread_join(tid,NULL);

    return 0;
}
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/sem.h> 
#define SHMKEY 70 
#define SEMKEY 80  
#define K      1024 
typedef int arr[16][256]; 
int shmid; 
int semid; 
void cleanup();
int main() 
{ 
	int i, in=0;   
	char *addr;   
	arr  *arrp;   
	struct sembuf ops1={0,-1,SEM_UNDO}, ops2={1, 1,SEM_UNDO};
	for (i=0; i<31; i++)      
		signal(i,cleanup);   
	shmid = shmget(SHMKEY, 16*K, 0777|IPC_CREAT);   
	addr = shmat(shmid, 0, 0);   
	arrp = (arr *)addr;   
	semid = semget(SEMKEY, 2, 0777|IPC_CREAT);   
	semctl(semid,0,SETVAL,16);   
	semctl(semid,1,SETVAL,0);   
	for (i=0; i<256; i++)   
	{     
		semop(semid, &ops1, 1);     
		(*arrp)[in][0] = i;     
		in = (in+1) % 16;     
		semop(semid, &ops2, 1);   
	}   
	sleep(1); 
	return 0;
} 

void cleanup()  
{ 
	shmctl(shmid,IPC_RMID,0);    
	semctl(semid,0,IPC_RMID,0);    
	exit(0);  
}  

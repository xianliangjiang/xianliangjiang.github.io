#include <pthread.h>
#include <stdio.h>
#include <unistd.h> 

#define _READR_NUM_ 3
#define _WRITER_NUM_ 2
pthread_rwlock_t lock;
int buf = 0;

void *read(void* _val)
{
	pthread_detach(pthread_self());
	while(1)
	{
		if(pthread_rwlock_tryrdlock(&lock) != 0)
		{
			printf(" writer is writting .. readr is waitting\n");
		}
		else
		{
			printf("readr is :%u, read val id: %d\n",
						pthread_self(), buf);
			pthread_rwlock_unlock(&lock);
		}
		sleep(1);
	}
}

void *write(void* _val)
{
	pthread_detach(pthread_self());
	while(1)
	{
		if(pthread_rwlock_tryrdlock(&lock) != 0)
		{
			printf(" readr is reading .. writer is waiting\n");
		}
		else
		{
		buf = rand();
			printf("writer is :%u, write val id: %d\n",
						pthread_self(), buf);
			pthread_rwlock_unlock(&lock);
		}
		sleep(1);
	}
}

int main()
{
	pthread_rwlock_init(&lock, NULL);
	pthread_t id;
	int i = 0;
	for(i = 0; i < _WRITER_NUM_; i++)
		pthread_create(&id, NULL, write, NULL);
	for(i = 0; i < _READR_NUM_; i++)
		pthread_create(&id, NULL, read, NULL);
	sleep(10);
	return 0;
}
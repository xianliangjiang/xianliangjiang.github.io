#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/sem.h> 
#define SHMKEY 70 
#define SEMKEY 80 
#define K      1024 
typedef int arr[16][256]; 
int shmid; 
int semid;   
int main() 
{ 
	int i, in=0;   
	char *addr;   
	arr  *arrp;   
	struct sembuf ops1={1,-1,SEM_UNDO}, ops2={0, 1,SEM_UNDO};  
	shmid = shmget(SHMKEY, 16*K, 0777);   
	addr = shmat(shmid, 0, 0);   
	arrp = (arr *)addr;   
	semid = semget(SEMKEY, 2, 0777);    
	for (i=0; i<256; i++)   
	{     
		semop(semid, &ops1, 1);     
		printf("sem2: %d = %d\n",i,(*arrp)[in][0]);     
		in = (in+1) % 16;     
		semop(semid, &ops2, 1);   
	} 
} 

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void *clean(char *name);

pthread_mutex_t brush, bucket;

int main(int argc, char *argv[])
{
    const int n = 2;
    pthread_t cleaners[n];
    char *names[] = {"Ivanon", "Petrov"};
    int i;
    pthread_mutex_init(&brush, NULL);
    pthread_mutex_init(&bucket, NULL);
    for(i = 0; i < n; i++) pthread_create(&cleaners[i], NULL, clean, (void *)names[i]);
    for(i = 0; i < n; i++) pthread_join(cleaners[i], NULL);
    pthread_mutex_destroy(&brush);
    pthread_mutex_destroy(&bucket);
    return 0;
}

void *clean(char *name)
{
    printf("%s starts work...\n", name);
    usleep(rand() % 1000000);
    if(name[0] == 'I')
    {
        usleep(rand() % 1000000);
        pthread_mutex_lock(&bucket);
        printf("%s takes bucket...\n", name);
        usleep(rand() % 1000000);
        pthread_mutex_lock(&brush);
        printf("%s takes brush...\n", name);
    }
    else
    {
        usleep(rand() % 1000000);
        pthread_mutex_lock(&brush);
        printf("%s takes brush...\n", name);
        usleep(rand() % 1000000);
        pthread_mutex_lock(&bucket);
        printf("%s takes bucket...\n", name);
    }
    printf("%s have finished cleaning!\n", name);
    usleep(rand() % 1000000);
    pthread_mutex_unlock(&brush);
    printf("%s puts brush...\n", name);
    usleep(rand() % 1000000);
    pthread_mutex_unlock(&bucket);
    printf("%s puts bucket...\n", name);
    printf("%s have finished work!\n", name);
    pthread_exit(NULL);
}

processinfo
===========

A basic Linux Kernel module, showing the information of a process working.

How To Use
===========
1) Make it using "make" command.
2) Add the module inside the kernel using "insmod ./process_info.ko <pid>", where <pid> refers the process ID.
